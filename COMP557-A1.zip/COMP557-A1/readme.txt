I’ve chosen the root to be the torso as it made making the character symmetric much easier. I’ve also included a bonus animation for an animation file that was mistakingly deleted. Hope you like it, I really enjoyed making it!

Michel Kassis
260662779